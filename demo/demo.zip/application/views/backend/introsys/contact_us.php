  <div class="page-header header-filter" data-parallax="true" style="background-image: url('<?php echo base_url(); ?>/assets/img/profile_city.jpg')">
    <div class="container">
      <div class="row">
        <div class="col-md-6">
          <h1 class="title">Anom The wonder Connectivity</h1>
          <h4>Get Connect ever slot of market and education system at a single plateform.<br>Complete solution for school, Institute, shop and Manufacturer</h4>
          <br>
          <a href="" target="_blank" class="btn btn-danger btn-raised btn-lg">
            <i class="fa fa-play"></i> Learn How it Work
          </a>
        </div>
      </div>
    </div>
  </div>
  <div class="main main-raised">
    <div class="container">
      <div class="section text-center">

    <div class="section section-tabs" style="background-color: #ffffff;">
      <div class="container">
      	<div class="section section-contacts">
      		<div class="row">
      		<div class="col-md-6">
      		Contact At : 8875210882,7413921234<br>
      		WhatsApp Number : 7413921234<br>
      		Mail : anomtechnology@gmail.com
      			</div>
      		<div class="col-md-6">
      			Address : 11-Narayan Vihar Jhag Bus Stand Bagru, Jaipur
      		</div>
      		</div>
      		
      	</div>
      <div class="section section-contacts">
        <div class="row">
          <div class="col-md-8 ml-auto mr-auto">
            <h2 class="text-center title">Work with us</h2>
            <form class="contact-form">
              <div class="row">
                <div class="col-md-6">
                  <div class="form-group">
                    <label class="bmd-label-floating">Your Name</label>
                    <input type="email" class="form-control">
                  </div>
                </div>
                <div class="col-md-6">
                  <div class="form-group">
                    <label class="bmd-label-floating">Your Email</label>
                    <input type="email" class="form-control">
                  </div>
                </div>
              </div>
              <div class="form-group">
                <label for="exampleMessage" class="bmd-label-floating">Your Message</label>
                <textarea type="email" class="form-control" rows="4" id="exampleMessage"></textarea>
              </div>
              <div class="row">
                <div class="col-md-4 ml-auto mr-auto text-center">
                  <button class="btn btn-primary btn-raised">
                    Send Message
                  </button>
                </div>
              </div>
            </form>
          </div>
        </div>
      </div>
    </div>
  </div>