<hr>
<style type="text/css">
  table {
    border-collapse: collapse;
}

td {
    padding-top: 1em;
    padding-bottom: 1em;
}

</style>

<table border="0" width="100%">
    <tr>
<td style="width: 100%; text-align: center;"><div style=""><h1 style="text-transform: uppercase;"><i class="entypo-qq"></i>  <a href="https://github.com/pawanjangid" target="_blank">pawan kumar jangid</a></h1></div></td>
    </tr>
    <tr style="margin-top: 10px;">
        <td style="width: 100%; text-align: center;">
        <center><a href="https://github.com/pawanjangid" target="_blank">
        <img style="max-height: 200px;" alt="upload img" src="<?php echo base_url() . 'uploads/developer/pawan_photo.jpg';  ?>" class="img-responsive img-circle" / ></a></center>

        </td>
        
    </tr>
    <tr style="text-align: center; font-weight: 600;margin-top: 20px;">
      <td>
         <h4><i class="entypo-graduation-cap"></i>  B.TECH from <a href="http://www.mnit.ac.in/" target="_blank">MNIT Jaipur</a> </h4>
      </td>   
    </tr>

</table>