<hr>
<style type="text/css">
  table {
    border-collapse: collapse;
}

td {
    padding-top: 1em;
    padding-bottom: 1em;
}

</style>
<table border="0" width="100%">
    <tr>
          <td style="width: 50%; text-align: center;"><div style=""><h1 style="text-transform: uppercase;">pawan kumar jangid</h1></div></td>
        
    </tr>
    <tr>
        <td style="width: 50%; text-align: center;">
           <h3><i class="entypo-mobile"></i>  <a href="tel:+918875210882" style="color: gray;">+918875210882</a></h3>
        </td>
    </tr>
    <tr style="text-align: center; font-weight: 600;margin-top: 50px; text-decoration: none;">
      <td>
       <h3><i class="entypo-mail"></i>  <a href="mailto:pawanjangid.ele@gmail.com" style="text-decoration: none;color: gray;">pawanjangid.ele@gmail.com</a></h3>
      </td>  
     
    </tr>
    <tr style="margin-top: 10px;">
        <td style="width: 50%; text-align: center;">
        <center>
        <img style="max-height: 250px;" alt="upload img" src="<?php echo base_url() . 'uploads/developer/pawan.jpg';  ?>"/></center>

        </td>
        <td style="width: 50%;">
        <center><h1><a href="<?php
              $myIp = getHostByName(getHostName());
              echo 'http://'.$myIp;
              ?>">
          <?php
              $myIp = getHostByName(getHostName());
              echo $myIp;
              ?></a>
                </h1>
        </center>
        </td>
    </tr>

</table>