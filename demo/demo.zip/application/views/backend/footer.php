<!-- Footer -->
<footer class="main">
	Powered By <strong><a href="http://www.anom.in ">anom.in</a></strong>. 
</footer>
