<?php

class Services_Twilio_Rest_TaskRouter_Activity extends Services_Twilio_TaskRouterInstanceResource {

}
